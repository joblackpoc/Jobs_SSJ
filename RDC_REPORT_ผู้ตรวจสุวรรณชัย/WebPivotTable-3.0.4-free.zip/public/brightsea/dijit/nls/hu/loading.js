//>>built
define("dijit/nls/hu/loading",{loadingState:"Bet\u00f6lt\u00e9s...",errorState:"Sajn\u00e1lom, hiba t\u00f6rt\u00e9nt"});