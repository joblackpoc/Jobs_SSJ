//>>built
define("dijit/nls/zh-tw/common",{buttonOk:"\u78ba\u5b9a",buttonCancel:"\u53d6\u6d88",buttonSave:"\u5132\u5b58",itemClose:"\u95dc\u9589"});