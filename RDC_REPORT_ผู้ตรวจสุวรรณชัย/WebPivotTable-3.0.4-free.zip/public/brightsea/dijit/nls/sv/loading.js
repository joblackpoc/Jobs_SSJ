//>>built
define("dijit/nls/sv/loading",{loadingState:"L\u00e4ser in...",errorState:"Det har intr\u00e4ffat ett fel."});