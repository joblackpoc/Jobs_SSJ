//>>built
define("dijit/form/nls/sl/ComboBox",{previousMessage:"Prej\u0161nje izbire",nextMessage:"Dodatne izbire"});