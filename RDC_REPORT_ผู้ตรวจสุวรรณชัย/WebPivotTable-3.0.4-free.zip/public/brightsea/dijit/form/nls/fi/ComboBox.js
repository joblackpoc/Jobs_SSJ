//>>built
define("dijit/form/nls/fi/ComboBox",{previousMessage:"Edelliset valinnat",nextMessage:"Lis\u00e4\u00e4 valintoja"});