//>>built
define("dijit/form/nls/pt/Textarea",{iframeEditTitle:"editar \u00e1rea",iframeFocusTitle:"editar quadro da \u00e1rea"});