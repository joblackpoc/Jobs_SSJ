//>>built
define("dgrid/extensions/nls/columnHider",{root:{popupTriggerLabel:"Show or hide columns",popupLabel:"Show or hide columns"},es:!0,ro:!0,sl:!0});