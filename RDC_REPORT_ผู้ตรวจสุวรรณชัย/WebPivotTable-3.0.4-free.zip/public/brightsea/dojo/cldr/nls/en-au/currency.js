//>>built
define("dojo/cldr/nls/en-au/currency",{EUR_displayName:"Euro",AUD_symbol:"$",USD_symbol:"US$"});