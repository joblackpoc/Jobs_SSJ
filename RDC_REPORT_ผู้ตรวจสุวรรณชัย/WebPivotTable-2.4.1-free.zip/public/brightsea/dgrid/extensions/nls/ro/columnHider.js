//>>built
define("dgrid/extensions/nls/ro/columnHider",{popupLabel:"Afi\u0219area sau ascunderea coloanelor"});