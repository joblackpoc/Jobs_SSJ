//>>built
define("dojo/cldr/nls/fr-ch/currency",{CHF_symbol:"CHF"});