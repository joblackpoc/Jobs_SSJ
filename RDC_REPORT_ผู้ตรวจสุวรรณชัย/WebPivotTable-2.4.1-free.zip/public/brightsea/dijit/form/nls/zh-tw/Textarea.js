//>>built
define("dijit/form/nls/zh-tw/Textarea",{iframeEditTitle:"\u7de8\u8f2f\u5340",iframeFocusTitle:"\u7de8\u8f2f\u5340\u6846"});